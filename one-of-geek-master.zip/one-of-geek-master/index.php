<!DOCTYPE html>
<html lang="ja" style="text-align:center;font-size: 62.5%;background-color: #000000;
    color: #fffff0;">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>PHP Task アンケート</title>
</head>
<body>
  <head>
    <div>
      <h2 class="feedbackT" style="text-align: center;
    font-size: 20px;">セルフアップアンケート</h2>
    </div>
    <div style="display:inline-flex;">
      <nav>
        <ul style="list-style: none;display: flex;align-items: center;font-size: 14px;">
          <li> <a href="#questionary" style="font:bold;text-decoration: none;color: #fffff0;">アンケート</a></li>
          <li> <a href="#preview" style="margin:30px;font:bold;text-decoration: none;color: #fffff0;">回答リスト</a></li>
        </ul>
      </nav>
    </div>
  </head>
  <main>
  <div id="questionary" style="text-align:center;">
    <h3>About</h3>
    <p>ゲームビジョン、達成できたこと<br>体験の向上を目指すアンケート</p>
  </div>
  <div id="questionary">
  <form method="post" action="todo_csv_create.php">
    <fieldset>
      <div>
        試合日: <input type="date" name="matchA">
      </div>
      <div>
        対戦Team: <input type="text" name="matchB">
      </div>
    </fieldset>
    <fieldset>
        <p><legend>ゲームビジョン</legend></p>
        <p>目標:<input type="text" name="attemptA" size="30"></p>
        <p>達成:<input type="text" name="attemptB" size="30"></p>
    </fieldset>
    <fieldset>
        <p><legend>できたこと</legend></p>
        <p>OF:<input type="text" name="correctA" size="30"></p>
        <p>DF:<input type="text" name="correctB" size="30"></p>
        <p>Best<input type="text" name="correctC" size="30"></p>
    </fieldset>
    <fieldset>
        <p><legend>できなかったこと</legend></p>
        <p>OF:<input type="text" name="ncorrectA" size="30"></p>
        <p>DF:<input type="text" name="ncorrectB" size="30"></p>
        <p>Bad:<input type="text" name="ncorrectC" size="30"></p>
    </fieldset>
    <fieldset>
        <p><legend>次への挑戦</legend></p>
        <p>自身<input type="text" name="tryA" size="30"></p>
        <p>Team<input type="text" name="tryB" size="30"></p>
    </fieldset>
    <fieldset>
        <p><legend>Man of the Match は？</legend></p>
        <p>MVP<input type="text" name="mvpA" size="30"></p>
        <p>理由<input type="text" name="mvpB" size="30"></p>
    </fieldset>

    <div class="send" style="margin: 20px 0 20px;
    text-align: center;">
      <input type="submit" value="送信">
    </div>

    <div id="preview" style="text-align: center;">
      <legend style="font-size: 14px;margin: 10px;">回答リスト</legend>
      <a href="todo_csv_read.php" style="font-size: 12px;color: #fffff0;text-decoration: none;">一覧へ</a>
    </div>
  </form>

  </div>

  </main>
  <footer></footer>
</body>
</html>