<?php
  function h($val){
    return htmlspecialchars($val,ENT_QUOTES);
  }

// 対戦・日時
$matchA = h($_POST['matchA']);
$matchB = h($_POST['matchB']);
// $$_POST['match[]'] = mb_convert_encoding($$_POST['match'],"UTF-8","SJIS");

$match = $_POST['match[]'];
foreach ( $match as $key => $val ) {
print "[$key] $val<br>"; 
}
exit();

// データの受取
$attemptA = h($_POST['attemptA']);
$attemptB = h($_POST['attemptB']);
// $attempt = $_POST['attempt'];

//できたこと
$correctA = h($_POST['correctA']);
$correctB = h($_POST['correctB']);
$correctC = h($_POST['correctC']);
// $correct = $_POST['correct'];

//できなかったこと
$ncorrectA = h($_POST['ncorrectA']);
$ncorrectB = h($_POST['ncorrectB']);
$ncorrectC = h($_POST['ncorrectC']);
// $ncorrect = $_POST['ncorrect'];

//改善・向上
$tryA = h($_POST['tryA']);
$tryB = h($_POST['tryB']);
// $try = $_POST['try'];

// MVP
$mvpA = h($_POST['mvpA']);
$mvpB = h($_POST['mvpB']);
// $mvp = $_POST['mvp'];

// 書き込みデータの作成（スペース区切りで最後に改行コードを追加）
  $write_data = array(
    array($matchA),
    array($matchB),
    array($attemptA),
    array($attemptB),
    array($correctA),
    array($correctB),
    array($correctC),
    array($ncorrectA),
    array($ncorrectB),
    array($ncorrectC),
    array($tryA),
    array($tryB),
    array($mvpA),
    array($mvpB)
  );
  // $write_data = [
  //   [$match,$attempt,$correct,$ncorrect,$try,$mvp],
  // ];

  // ファイルを開く処理
  $file = fopen('data/todo.csv', 'a');

  foreach($write_data as $fields){
    fputcsv($file,$fields);

  // ファイルロックの処理
  flock($file, LOCK_EX);
  
  // ファイル書き込み処理
  fwrite($file, $write_data);
  
  // ファイルアンロックの処理
  flock($file, LOCK_UN);
  
  // ファイルを閉じる処理
}
  fclose($file);

// 入力画面へ移動
header("Location:index.php");

// txtファイルへの書き込みのみ行うので表示する画面は存在しない
