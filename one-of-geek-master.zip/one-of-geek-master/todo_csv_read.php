<?php
// 出力用の文字列（ここに読み込んだデータをタグに入れた形式で追加していく）
$str = '';
$file = fopen('data/todo.csv','r');

// ファイルロックの処理
flock($file, LOCK_EX);

// ファイル書き込み処理
// 1行づつ取り出す

if($file){
  while($line = fgets($file)){
    // var_dump($line);
    // exit();
    $str .="<tr><td>{$line}</td></tr>";
  }
}
flock($file, LOCK_UN);
fclose($file);

?>

<!DOCTYPE html>
<html lang="ja" style="background-color: #000000;
    color: #fffff0;">

<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>textファイル書き込み型todoリスト（一覧画面）</title>
</head>

<body>
  <fieldset>
    <legend>自己フィードバック一覧</legend>
    <table>
      <thead style="text-align: left;">
        <tr>
          <th>リスト</th>
        </tr>
      </thead>
      <tbody style="text-align: left;">
        <tr>
          <th><?= $str?></th>
        </tr>
      </tbody>
    </table>
  </fieldset>
  <div class="topReturn" style="margin: 20px 0 20px;
    text-align: center;">
    <a href="index.php" style="color: #fffff0;text-decoration: none;">アンケート画面へ戻る</a>
  </div>
</body>
</html>