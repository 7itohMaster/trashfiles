class TweetsController < ApplicationController
    def index
    end
end