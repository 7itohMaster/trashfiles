# gcl_AI_tensorFlow
Google colaboratory TensorFlow_js
