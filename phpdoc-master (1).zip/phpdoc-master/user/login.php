<!DOCTYPE html>
<html lang="ja">

<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>user manager</title>
</head>

<body>
  <header>
    <section>
      <div>
        <h1>ユーザー管理</h1>
      </div>
    </section>
  </header>
  <main>
    <div>
      <form method="POST" action="login_act.php">
        <fieldset>
          <legend>ユーザー入力</legend>
          <div>
            ユーザーID: <input type="text" name="lid">
          </div>
          <div>
            ログインpwd: <input type="text" name="lpw">
          </div>
        </fieldset>
        <div>
          <input type="submit" value="ログイン">
        </div>
        <!-- <a href="todo_read.php">支払い一覧</a> -->
      </form>
    </div>
  </main>

</body>

</html>