<?php
session_start();
include ('funcs.php');
loginCheck();

// DB接続の設定
include('functions.php');

$pdo = connect_to_db();

// SQL準備&実行
$sql ='SELECT * FROM gs_login_table';

$stmt = $pdo->prepare($sql);
$status = $stmt->execute();

  // データ登録処理後
  $view='';
  if ($status == false) {
    // SQL実行に失敗した場合はここでエラーを出力し，以降の処理を中止する
    $error = $stmt->errorInfo();
    exit('sqlError:'.$error[2]);
  } else {
  $result = $stmt->fetchAll(PDO::FETCH_ASSOC);
  $output = "";

  foreach($result as $record){
    $output .= "<tr>";
    $output .= "<td>{$record["indate"]}</td>";
    $output .= "<td>{$record["u_name"]}</td>";
    // edit deleteリンクを追加
    $output .= "<td><a href='todo_edit.php?id={$record["id"]}'>edit</a></td>";
    $output .= "<td><a href='todo_delete.php?id={$record["id"]}'>delete</a></td>";
    $output .= "</tr>";
  }
}

?>
<!DOCTYPE html>
<html lang="ja">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>login select</title>
</head>
<body>
  <section>
    <div>
      <h1>データ一覧</h1>
    </div>
  </section>
  <a href="login.php">トップ画面へ</a>
  <fieldset>
    <legend>ユーザー情報</legend>
    <table>
      <thead>
        <tr>
          <th>Date</th>
          <th>User</th>
          <th>Update</th>
          <th>Delete</th>
        </tr>
      </thead>
      <tbody>
        <!-- ここに<tr><td>deadline</td><td>todo</td><tr>の形でデータが入る -->
        <?= $output ?>
      </tbody>
    </table>
  </fieldset>
  <a href="logout.php">ログアウト</a>

</body>
</html>
