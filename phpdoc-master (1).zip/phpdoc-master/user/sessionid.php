<?php
  session_start();

  $sid = session_id();
  // $_SESSION["name"] = "やまざき";
  // $_SESSION["num"] = 1000;
  // $_SESSION["auth"] = 1000;
  // $_SESSION["value"] = 100;

  echo $sid;
?>