<?php
session_start();
include('functions.php');

// 項目入力のチェック
if(
  !isset($_POST['lid']) || $_POST['lid']=='' ||
  !isset($_POST['lpw']) || $_POST['lpw']==''
) {
  echo json_encode(["error_msg" => "no input"]);
  exit();
}

$lid = $_POST['lid'];
$lpw = $_POST['lpw'];

// var_dump($_POST);

$pdo = connect_to_db();

// データ登録SQL作成
$sql = "SELECT * FROM gs_login_table WHERE u_id=:lid AND u_pw=:lpw";
// SQL準備&実行
$stmt = $pdo->prepare($sql);
$stmt->bindValue(':lid', $lid, PDO::PARAM_STR);
$stmt->bindValue(':lpw', $lpw, PDO::PARAM_STR);
$status = $stmt->execute();

// データ登録処理後
if ($status == false) {
  $error = $stmt->errorInfo();
  exit("QueryError:".$error[2]);
} 

$val = $stmt->fetch();

if($val["id"] != ""){
  $_SESSION["chk_ssid"]  = session_id();
  $_SESSION["u_name"]  = $val['u_name'];
  header("Location: select.php");
}else {
  header("Location:login.php");
  exit();
}