<!DOCTYPE html>
<html lang="ja">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>SQLlesson</title>
</head>
<body>
  <head>
    <section>
      <div>
        <h1>SQL Lesson UserAuth</h1>
      </div>
    </section>
  </head>
  <main>

    <section>
      <form action="insert.php" method="post">
        <fieldset>
          <legend>アンケートフォーム</legend>
          <div>
            名前<input type="text" name="username">
          </div>
          <div>
            メール<input type="text" name="email">
          </div>
          <div>
            <textarea name="content" cols="40" rows="10"></textarea>
          </div>
          <div>
            <input type="submit" value="送信">
          </div>
        </fieldset>
      </form>
    </section>

  </main>
  <footer></footer>
</body>
</html>