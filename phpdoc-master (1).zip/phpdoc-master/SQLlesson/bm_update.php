<?php
  // 
  $id = $_POST["id"];
  $bookname = $_POST["bookname"];
  $bookurl = $_POST["bookurl"];
  $bookrecommend = $_POST["bookrecommend"];

  //DB接続
  try{
    $pdo = new PDO('mysql:dbname=gs_db;charset=utf8;port=3306;host=localhost','root','');
  } catch(PDOException $e){
    exit('DbConnectError:'.$e->getMessage());
  }

  // SQL作成

  $update = $pdo->prepare("UPDATE gs_bm_table SET bookname=:bookname, bookurl=:bookurl, bookrecommend=:bookrecommend WHERE id=:id");

  $update->bindValue(':bookname', $bookname, PDO::PARAM_STR);
  $update->bindValue(':bookurl', $bookurl, PDO::PARAM_STR);
  $update->bindValue(':bookrecommend', $bookrecommend, PDO::PARAM_STR);
  $update->bindValue(':id', $id, PDO::PARAM_INT);

  $status = $update->execute();
  header("Location: bm_select.php");

  // データ登録後の処理
  if($status==false){
    $error = $stmt->error->errorInfo();
    exit("QuerryError:".$error[2]);
  } else{
    header("Location: bm_select.php");
    exit();
  }

?>