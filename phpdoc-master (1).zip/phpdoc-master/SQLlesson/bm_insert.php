<?php

  // エラーチェック
  if(
    !isset($_POST['bookname']) || ($_POST['bookname'])=='' ||
    !isset($_POST['bookurl']) || ($_POST['bookurl'])=='' ||
    !isset($_POST['bookrecommend']) || ($_POST['bookrecommend'])==''
  ){
    exit('ParamError');
  }

  // データ取得 POST
  $bookname = $_POST['bookname'];
  $bookurl = $_POST['bookurl'];
  $bookrecommend = $_POST['bookrecommend'];

  // var_dump($bookname, $bookurl, $bookrecommend);
  // exit('check');

  //DB接続

  try{
    $pdo = new PDO('mysql:dbname=gs_db;charset=utf8;port=3306;host=localhost','root','');
  } catch(PDOException $e){
    exit('DbConnectError:'.$e->getMessage());
  }

  // SQL データ登録・作成
  $sql ="INSERT INTO gs_bm_table(id, bookname, bookurl, bookrecommend, addtime) VALUE(NULL, :bookname, :bookurl, :bookrecommend, sysDate())";

  // SQL 準備
  $stmt = $pdo -> prepare($sql);

  $stmt -> bindValue(':bookname', $bookname, PDO::PARAM_STR);
  $stmt -> bindValue(':bookurl', $bookurl, PDO::PARAM_STR);
  $stmt -> bindValue(':bookrecommend', $bookrecommend, PDO::PARAM_STR);

  // SQL 実行
  $status = $stmt->execute();

  // データ登録処理後
  if($status==false){
    $error = $stmt->errorInfo();
    exit("QueryError:".$error[2]);
  } else{
    header("Location: bm_index.php");
  }

?>