<?php
  $id = $_GET["id"];

    //DB接続
    try{
      $pdo = new PDO('mysql:dbname=gs_db;charset=utf8;port=3306;host=localhost','root','');
    } catch(PDOException $e){
      exit('DbConnectError:'.$e->getMessage());
    }
  
    // SQL取得
    $sql = "DELETE FROM gs_bm_table WHERE id=:id";
    $stmt = $pdo->prepare($sql);
    $stmt ->bindValue(':id',$id, PDO::PARAM_INT);
    $status = $stmt->execute();

    //データ登録後処理
    if($status == false){
      $error = $stmt->errorInfo();
      exit("QueryError:".$error[2]);
    } else{
      header("Location: bm_select.php");
      exit();
    }
?>