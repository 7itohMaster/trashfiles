<!DOCTYPE html>
<html lang="ja">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Book SQL lesson</title>
</head>
<body>
  <header>
    <section>
      <h1>書籍アンケート</h1>
    </section>
  </header>
  <main>
    <section>
      <div>
        <form action="bm_insert.php" method="POST">
          <fieldset>
            <legend>アンケートフォーム</legend>
            <div>書籍名<input type="text" name="bookname" id=""></div>
            <div>書籍URL<input type="text" name="bookurl" id=""></div>
            <div>書評<textarea name="bookrecommend" id="" cols="30" rows="10"></textarea></div>
            <div><input type="submit" value="投稿"></div>
          </fieldset>
        </form>
      </div>
    </section>

    <section>
      <div>
        <a href="bm_select.php">書評リスト</a>
      </div>
    </section>
    
  </main>
  
</body>
</html>