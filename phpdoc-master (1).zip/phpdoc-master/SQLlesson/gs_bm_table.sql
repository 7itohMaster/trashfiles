-- phpMyAdmin SQL Dump
-- version 5.0.2
-- https://www.phpmyadmin.net/
--
-- ホスト: localhost
-- 生成日時: 2020 年 6 月 08 日 10:56
-- サーバのバージョン： 10.4.11-MariaDB
-- PHP のバージョン: 7.2.30

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- データベース: `gs_db`
--

-- --------------------------------------------------------

--
-- テーブルの構造 `gs_bm_table`
--

CREATE TABLE `gs_bm_table` (
  `id` int(11) NOT NULL,
  `bookname` varchar(128) COLLATE utf8_unicode_ci NOT NULL,
  `bookurl` text COLLATE utf8_unicode_ci DEFAULT NULL,
  `bookrecommend` text COLLATE utf8_unicode_ci DEFAULT NULL,
  `addtime` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- テーブルのデータのダンプ `gs_bm_table`
--

INSERT INTO `gs_bm_table` (`id`, `bookname`, `bookurl`, `bookrecommend`, `addtime`) VALUES
(1, 'PHP本', 'http://php.jp', '読みたい本', '2020-06-06 20:27:44'),
(2, 'JS本', 'http://JS.jp', '困ったら再度読みたい本', '2020-06-06 20:28:53'),
(3, 'FB本', 'http://Firebase.jp', '構築で読みたい本', '2020-06-06 20:29:32'),
(4, 'Threejs本', 'http://ThreeJS.jp', '3D表現で読みたい本', '2020-06-06 20:30:24'),
(5, 'AI本', 'http://AI.jp', 'AIの構築で読みたい本', '2020-06-06 20:31:20'),
(6, 'WebXR本', 'http://WebXR.jp', '拡張現実で読みたい本', '2020-06-06 20:32:36'),
(7, 'IoT本', 'http://IoT.jp', 'IoTで読みたい本', '2020-06-06 20:33:36'),
(8, 'test5本', 'http://test.test55', 'aaaaaa55', '2020-06-07 00:37:55'),
(9, 'test2本', 'http://test2.test', 'aaaaaaBBBBBBB', '2020-06-07 00:42:16'),
(10, 'AI2本', 'http://AI2.jp', 'AI2', '2020-06-07 09:14:20'),
(11, 'test4', 'http://test.test4', 'aaaaaaa44', '2020-06-08 12:21:53');

--
-- ダンプしたテーブルのインデックス
--

--
-- テーブルのインデックス `gs_bm_table`
--
ALTER TABLE `gs_bm_table`
  ADD PRIMARY KEY (`id`);

--
-- ダンプしたテーブルのAUTO_INCREMENT
--

--
-- テーブルのAUTO_INCREMENT `gs_bm_table`
--
ALTER TABLE `gs_bm_table`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
