<!DOCTYPE html>
<html lang="ja">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>IMG Lesson</title>
</head>
<body>
  <header>
    <section>
      <h1>画像</h1>
    </section>
  </header>
  <main>
  </main>
  <footer></footer>
</body>
</html>