<?php




// カウント指定
// $sql = 'SELECT COUNT(*) as cnt FROM gs_bm_table WHERE bookname LIKE '%PHP%'';

?>