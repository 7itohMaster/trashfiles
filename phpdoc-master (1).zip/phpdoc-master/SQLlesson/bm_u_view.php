<?php
  //GETでデータ取得　パラメータを取得する
  $id = $_GET["id"];
  // var_dump($id);
  // exit('id');

  //DB接続
  try{
    $pdo = new PDO('mysql:dbname=gs_db;charset=utf8;port=3306;host=localhost','root','');
  } catch(PDOException $e){
    exit('DbConnectError:'.$e->getMessage());
  }

  // SQL取得
  $sql = "SELECT * FROM gs_bm_table WHERE id=:id";
  $stmt = $pdo->prepare($sql);
  $stmt ->bindValue(':id',$id, PDO::PARAM_INT);
  $status = $stmt->execute();

  // var_dump($stmt);

  // データ表示
  $view = "";

  if($status == false){
    $error = $stmt->errorInfo();
    exit("ErrorQuery:".$error[2]);
  }else{
    $row = $stmt->fetch();
    //$row["id"], $row["name"]...
  }

?>

<!DOCTYPE html>
<html lang="ja">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Book View Edit</title>
</head>
<body>
  <header>
    <section>
      <h1>書評更新</h1>
    </section>
  </header>
  <main>
    <form action="bm_update.php" method="POST">
      <div><a href="bm_index.php">トップへ戻る</a></div>
      <fieldset>
        <legend>書評更新</legend>
        <div><input type="text" name="bookname" id="" value="<?= $row["bookname"]?>"></div>
        <div><input type="text" name="bookurl" id="" value="<?= $row["bookurl"]?>"></div>
        <div>
          <textarea name="bookrecommend" id="" cols="30" rows="10"><?= $row["bookrecommend"]?></textarea>
        </div>
        <input type="hidden" name="id" value="<?= $row["id"]?>">
        <div><input type="submit" value="更新"></div>
      </fieldset>
    </form>

  </main>
  <footer></footer>
</body>
</html>