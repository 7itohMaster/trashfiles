<?php
  // DB接続
  try{
    $pdo = new PDO('mysql:dbname=gs_db;charset=utf8;port=3306;host=localhost','root','');
  } catch(PDOException $e){
    exit('DbConnectError:'.$e->getMessage());
  }

  // SQLデータ情報を取得する
  $stmt = $pdo->prepare("SELECT * FROM gs_bm_table");
  $status = $stmt->execute();

  //データ登録処理後
  $view = "";
  if($status == false){
    $error = $stmt->errorInfo();
    exit("ErrorQuery:".$error[2]);
  }else{
    $result = $stmt->fetchAll(PDO::FETCH_ASSOC);
    foreach($result as $record){
      $view .= "<tr>";
      $view .= "<td>";
      $view .= $record["addtime"];
      $view .= "</td>";
      $view .= "<td>";
      $view .= $record["bookname"];
      $view .= "</td>";
      $view .= "<td>";
      $view .= '<a href="bm_u_view.php?id='.$record["id"].'">';
      $view .= "edit</a>";
      $view .= "</td>";
      $view .= "<td>";
      $view .= '<a href="bm_delete.php?id='.$record["id"].'">';
      $view .= "delete</a>";
      $view .= "</td>";
      $view .= "</tr>";
    }
  }

?>
<!DOCTYPE html>
<html lang="ja">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Book Select list</title>
</head>
<body>
  <header>
    <section>
      <h1>書評リスト</h1>
    </section>
  </header>
  <main>
    <section>
      <a href="bm_index.php">トップメニューへ戻る</a>
    </section>
    <section>
      <fieldset>
        <legend>書評一覧</legend>
        <!-- <?= $view2?> -->
        <table>
          <div>
            <thead style="display:flex;">
              <tr>
                <th>日付</th>
                <th>書籍名</th>
                <th>URL</th>
              </tr>
            </thead>
          </div>
          <tbody>
            <?= $view?>
          </tbody>
        </table>
      </fieldset>
    </section>
  </main>
</body>
</html>