<?php

// 項目入力のチェック
if(
  !isset($_POST["username"]) || $_POST["username"]=="" ||
  !isset($_POST["email"]) || $_POST["email"]=="" ||
  !isset($_POST["content"]) || $_POST["content"]==""
  ){
    exit('ParamError');
  }
  
  // データ取得 POST
  // 受け取ったデータを変数に入れる
  $username = $_POST["username"];
  $email = $_POST["email"];
  $content = $_POST["content"];
  // var_dump($name, $email, $content);
  // exit('name,email,content');

  // DB接続
  try{
    $pdo = new PDO('mysql:dbname=gs_db;charset=utf8;port=3306;host=localhost','root','');
  } catch(PDOException $e){
    exit('DbConnectError:'.$e->getMessage());
  }

  // function connect_to_db(){
  //   $dbn='mysql:dbname=gsacf_l03_10;charset=utf8;port=3306;host=localhost';
  //   $user = 'root';
  //   $pwd = '';
  //   try {
  //         return new PDO($dbn, $user, $pwd);
  //     } catch (PDOException $e) { exit('dbError:'.$e->getMessage());
  //   } 
  // }
  
  // データ登録SQL作成
  $sql = "INSERT INTO gs_an_table(id, username, email, content,indate) VALUE(NULL, :username, :email, :content, sysdate())";

  // SQL準備&実行
  $stmt = $pdo -> prepare($sql);

  $stmt -> bindValue(':username', $username, PDO::PARAM_STR);
  $stmt -> bindValue(':email', $email, PDO::PARAM_STR);
  $stmt -> bindValue(':content', $content, PDO::PARAM_STR);

  $status = $stmt->execute();

  // $flag = $stmt->execute();

  // データ登録処理後

  if($status==false){
    $error = $stmt->errorInfo();
    exit("QueryError:".$error[2]);
  } else{
    header("Location: index.php");
  }

?>