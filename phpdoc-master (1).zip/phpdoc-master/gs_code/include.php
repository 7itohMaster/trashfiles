<?php
  include("menu.html");
  include("date.php");
?>