<?php
  $arBase = array("php4","php5","php7<br>");
  var_dump($arBase);
  echo($arBase[1]);

  // 文字列の置き換えを行う
  // 置換文字, 変更後文字, リプレースする変数
  $sTr = str_replace("php4","php5.5",$arBase);
  var_dump($sTr);
  echo($sTr[0]);

  $arBase1 = "Hello_こんにちは_0000<br>";
  var_dump($arBase1);

  $sTr1 = str_replace("Hello","Good Morning",$arBase1);
  echo($sTr1);

  //文字列を配列に変換する
  $sTr2 = "A,B,C,D";
  var_dump($sTr2);
  $sTr2 = explode(",",$sTr2);
  var_dump($sTr2);



?>