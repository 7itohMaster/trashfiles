<?php

  function k($val){
    return htmlspecialchars($val,ENT_QUOTES);
  }

  function kuji(){
    $omikuji = rand(1,5);
  
    if($omikuji == 1){
      echo ("大吉");
    } else if($omikuji == 2){
      echo ("中吉");
    } else if($omikuji == 3){
      echo ("小吉");
    } else if($omikuji == 4){
      echo ("末吉");
    } else
      echo ("凶");
  }

?>

<!DOCTYPE html>
<html lang="ja">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>OMIKUJI PHP</title>
</head>
<body>
  <p><?php echo(kuji())?></p>
</body>
</html>