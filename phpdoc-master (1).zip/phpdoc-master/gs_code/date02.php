<?php
  $d = date("s");

  if($d >= 0 && $d <= 19){
    echo '<p style="background-color:red;color:white;">'.$d.'秒</p>';
  } else if($d >= 20 && $d <= 39){
    echo '<p style="background-color:white;color:black;">'.$d.'秒</p>';
  }else {
    echo '<p style="background-color:blue;color:white;">'.$d.'秒</p>';
  }
  echo '<p style="background-color:red;color:white;">現在：'.$d.'秒</p>';

?>