<?php

  include("xss.php");

  // function h($val){
  //   return htmlspecialchars($val,ENT_QUOTES);
  // }

  function kuji(){
    $omikuji = rand(1,5);
    
    if($omikuji == 1){
      echo ("大吉");
    } else if($omikuji == 2){
      echo ("中吉");
    } else if($omikuji == 3){
      echo ("小吉");
    } else if($omikuji == 4){
      echo ("末吉");
    } else
    echo ("凶");
  }

  $name = $_POST["name"];
  $age = $_POST["age"];

?>

<!DOCTYPE html>
<html lang="ja">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>TEST HTML PHP02</title>
</head>
<body>
  <form method="POST" action="test.php" >
  <p>名前：<input type="text" name="name" size="20" value="<?= h($name); ?>"></p>
  <p>年齢：<input type="text" name="age" size="20" value="<?= h($age); ?>"></p>
  <p>おみくじ<input type="text" name="omikuji" size="20" value="<?= h(kuji())?>"></p>
  <p><input type="submit" value="おみくじを引く"></p>
  </form>
</body>
</html>