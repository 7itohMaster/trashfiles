<!DOCTYPE html>
<html lang="ja">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>PHP Basic Lesson</title>
</head>
<body>

<form method="POST" action="test.php">
  <p>名前<input type="text" name="name" size="20"></p>
  <p>年齢<input type="text" name="age" size="20"></p>
  <p>おみくじ<input type="text" name="omikuji" size="20"></p>
  <p><input type="submit" value="おみくじを引く"></p>
  </form>
  
</body>
</html>