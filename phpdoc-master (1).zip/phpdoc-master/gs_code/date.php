<?php
  $date = date("Y-M-D H:i:s");
  echo $date;

  // echo date("Y年M月d日 H時i分s秒");
  // echo "<br>";
  // echo date("Y/M/D");
  // echo "<br>";
  // echo date("H:i:s");

?>